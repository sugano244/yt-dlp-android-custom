# yt-dlp on Android

この一式には2通りのAndroid対応を入れています。

## 1. 本家yt-dlpをほぼそのまま使う（推奨）

`install-termux-yt-dlp.sh` をTermuxで1回実行します。

設定される内容:
- 公式Python版 `yt-dlp[default]`
- FFmpeg
- 保存先 `Download/yt-dlp`
- Androidの共有メニュー → Termux → yt-dlpダウンロード
- `ydl "URL"` コマンド
- `ydlaudio "URL"` でMP3抽出

### 実行例

```bash
bash /storage/emulated/0/Download/install-termux-yt-dlp.sh
```

初回の `termux-setup-storage` ではAndroidのストレージ許可を承認してください。

## 2. 通常のAndroid GUIアプリ

`app/` はAndroid Studio用のGUIアプリです。

機能:
- URL貼り付け
- Android共有メニューからURL受け取り
- 動画MP4 / 最高品質の単一動画 / 音声M4A
- プレイリスト切替
- 完了後 `Download/yt-dlp` に保存
- 端末側にPython/Termux不要

対応:
- Android 10以上
- arm64-v8a実機 / x86_64エミュレータ

Android Studioでプロジェクトを開き、Gradle 8.9 / JDK 17でビルドしてください。
GitHub Actions用 `.github/workflows/android.yml` も同梱しています。

GUI版は `dev.ffmpegkit-maintained:yt-dlp-android:2.0.2` を利用しています。このAARはPython 3.13とyt-dlpを内包しますが、任意のCLIオプションを完全には透過しないため、本家yt-dlpの全機能が必要ならTermux版を使ってください。

## 注意

保存する権利のあるコンテンツ、または各サービスの規約で許可された範囲で利用してください。
