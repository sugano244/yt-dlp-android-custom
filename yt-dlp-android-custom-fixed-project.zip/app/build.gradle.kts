plugins {
    id("com.android.application")
}

android {
    namespace = "jp.chatgpt.ytdlpandroid"
    compileSdk = 35

    defaultConfig {
        applicationId = "jp.chatgpt.ytdlpandroid"
        minSdk = 29
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"

        ndk {
            abiFilters += setOf("arm64-v8a", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
    }
}

dependencies {
    implementation("dev.ffmpegkit-maintained:yt-dlp-android:2.0.2")
    implementation("dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9")
}
