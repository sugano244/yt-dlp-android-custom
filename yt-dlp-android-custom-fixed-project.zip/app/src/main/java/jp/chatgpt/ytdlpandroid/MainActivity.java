package jp.chatgpt.ytdlpandroid;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Future;

import dev.ffmpegkit_maintained.ytdlp.DownloadProgressCallback;
import dev.ffmpegkit_maintained.ytdlp.YtDlp;
import dev.ffmpegkit_maintained.ytdlp.YtDlpException;
import dev.ffmpegkit_maintained.ytdlp.YtDlpRequest;
import dev.ffmpegkit_maintained.ytdlp.YtDlpResponse;

import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.ReturnCode;

public class MainActivity extends Activity {
    private EditText urlInput;
    private Spinner modeSpinner;
    private CheckBox playlistCheck;
    private EditText extraArgsInput;
    private EditText startTimeInput;
    private EditText endTimeInput;
    private CheckBox wavSectionCheck;
    private Button downloadButton;
    private ProgressBar progressBar;
    private TextView statusText;
    private volatile boolean initialized = false;
    private volatile boolean downloading = false;
    private Future<YtDlpResponse> activeDownload;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(buildUi());
        handleIncomingIntent(getIntent());
        initializeYtDlp();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private View buildUi() {
        int pad = dp(18);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(28), pad, dp(28));
        scroll.addView(root, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT,
                ScrollView.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(this);
        title.setText("yt-dlp Android");
        title.setTextSize(28);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("URLを貼り付けて、AndroidのDownload/yt-dlpへ保存します。");
        sub.setTextSize(14);
        sub.setPadding(0, dp(8), 0, dp(20));
        root.addView(sub);

        urlInput = new EditText(this);
        urlInput.setHint("https://...");
        urlInput.setSingleLine(false);
        urlInput.setMinLines(2);
        urlInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        root.addView(urlInput, matchWrap());

        LinearLayout urlButtons = new LinearLayout(this);
        urlButtons.setOrientation(LinearLayout.HORIZONTAL);
        urlButtons.setGravity(Gravity.END);

        Button paste = new Button(this);
        paste.setText("貼り付け");
        paste.setOnClickListener(v -> pasteClipboard());
        urlButtons.addView(paste);

        Button clear = new Button(this);
        clear.setText("クリア");
        clear.setOnClickListener(v -> urlInput.setText(""));
        urlButtons.addView(clear);
        root.addView(urlButtons, matchWrap());

        TextView modeLabel = label("保存形式");
        modeLabel.setPadding(0, dp(16), 0, dp(6));
        root.addView(modeLabel);

        modeSpinner = new Spinner(this);
        String[] modes = {
                "動画 MP4（音声入り・互換性優先）",
                "動画（最高品質の単一ファイル）",
                "音声 M4A / 最高音質"
        };
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, modes);
        modeSpinner.setAdapter(adapter);
        root.addView(modeSpinner, matchWrap());

        playlistCheck = new CheckBox(this);
        playlistCheck.setText("プレイリスト全体を対象にする");
        playlistCheck.setChecked(false);
        root.addView(playlistCheck);

        wavSectionCheck = new CheckBox(this);
        wavSectionCheck.setText("指定区間をWAVで保存（YouTubeはformat 140を優先）");
        wavSectionCheck.setChecked(true);
        root.addView(wavSectionCheck);

        TextView sectionLabel = label("切り出し時間（例 7:36.25 ～ 13:35）");
        sectionLabel.setPadding(0, dp(10), 0, dp(6));
        root.addView(sectionLabel);

        LinearLayout timeRow = new LinearLayout(this);
        timeRow.setOrientation(LinearLayout.HORIZONTAL);
        startTimeInput = new EditText(this);
        startTimeInput.setHint("開始 7:36.25");
        startTimeInput.setSingleLine(true);
        timeRow.addView(startTimeInput, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        endTimeInput = new EditText(this);
        endTimeInput.setHint("終了 13:35");
        endTimeInput.setSingleLine(true);
        timeRow.addView(endTimeInput, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(timeRow, matchWrap());

        TextView advancedLabel = label("追加のyt-dlpオプション（任意）");
        advancedLabel.setPadding(0, dp(12), 0, dp(6));
        root.addView(advancedLabel);

        extraArgsInput = new EditText(this);
        extraArgsInput.setHint("対応例: --restrict-filenames / --add-header \"Referer: ...\"");
        extraArgsInput.setMinLines(2);
        extraArgsInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        root.addView(extraArgsInput, matchWrap());

        downloadButton = new Button(this);
        downloadButton.setText("初期化中…");
        downloadButton.setEnabled(false);
        downloadButton.setOnClickListener(v -> startDownload());
        LinearLayout.LayoutParams btnLp = matchWrap();
        btnLp.topMargin = dp(20);
        root.addView(downloadButton, btnLp);

        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(1000);
        progressBar.setProgress(0);
        LinearLayout.LayoutParams progressLp = matchWrap();
        progressLp.topMargin = dp(18);
        root.addView(progressBar, progressLp);

        statusText = new TextView(this);
        statusText.setText("yt-dlpを準備しています…");
        statusText.setTextSize(13);
        statusText.setPadding(0, dp(8), 0, 0);
        root.addView(statusText, matchWrap());

        TextView note = new TextView(this);
        note.setText("※ 自分が保存する権利を持つコンテンツや、各サービスの規約で許可された範囲で利用してください。\n" +
                "※ 区間WAV保存ではHLSを避け、M4Aを取得後に端末内FFmpegで切り出します。\n" +
                "※ 本家yt-dlpの全機能を使う場合は同梱のTermuxセットアップを利用してください。");
        note.setTextSize(12);
        note.setPadding(0, dp(24), 0, 0);
        root.addView(note, matchWrap());

        return scroll;
    }

    private void initializeYtDlp() {
        new Thread(() -> {
            try {
                YtDlp.init(getApplicationContext());
                initialized = true;
                runOnUiThread(() -> {
                    statusText.setText("準備完了");
                    downloadButton.setText("ダウンロード");
                    downloadButton.setEnabled(true);
                });
            } catch (YtDlpException e) {
                runOnUiThread(() -> {
                    statusText.setText("初期化に失敗しました: " + safe(e.getMessage()));
                    downloadButton.setText("初期化失敗");
                });
            }
        }, "ytdlp-init").start();
    }

    private void startDownload() {
        if (!initialized || downloading) return;

        String url = extractFirstUrl(urlInput.getText().toString().trim());
        if (url == null) {
            urlInput.setError("http:// または https:// のURLを入力してください");
            return;
        }

        downloading = true;
        downloadButton.setEnabled(false);
        downloadButton.setText("ダウンロード中…");
        progressBar.setProgress(0);
        statusText.setText("開始しています…");

        File base = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
        File sessionDir = new File(base, "yt-dlp/session-" + System.currentTimeMillis());
        if (!sessionDir.mkdirs() && !sessionDir.isDirectory()) {
            finishWithError("一時保存先を作成できませんでした。");
            return;
        }

        String template = new File(sessionDir, "%(title).180B [%(id)s].%(ext)s").getAbsolutePath();
        YtDlpRequest request = new YtDlpRequest(url)
                .setOutputTemplate(template)
                .addOption("--no-mtime");

        if (!playlistCheck.isChecked()) {
            request.addOption("--no-playlist");
        }

        boolean sectionWav = wavSectionCheck.isChecked();
        String sectionStart = startTimeInput.getText().toString().trim();
        String sectionEnd = endTimeInput.getText().toString().trim();
        if (sectionWav && (sectionStart.isEmpty() || sectionEnd.isEmpty())) {
            finishWithError("WAV区間保存を使う場合は開始時間と終了時間を入力してください。");
            deleteRecursively(sessionDir);
            return;
        }

        if (sectionWav) {
            // HLS itag 234を避ける。YouTubeでは通常のM4A/AAC itag 140を最優先。
            request.addOption("-f", "140/bestaudio[ext=m4a]/bestaudio");
        } else switch (modeSpinner.getSelectedItemPosition()) {
            case 0:
                request.addOption("-f", "best[ext=mp4][vcodec!=none][acodec!=none]/best[vcodec!=none][acodec!=none]");
                break;
            case 1:
                request.addOption("-f", "best[vcodec!=none][acodec!=none]");
                break;
            case 2:
                request.addOption("-f", "bestaudio[ext=m4a]/bestaudio");
                break;
            default:
                request.addOption("-f", "best");
        }

        try {
            for (String arg : splitArgs(extraArgsInput.getText().toString())) {
                request.addOption(arg);
            }
        } catch (IllegalArgumentException e) {
            finishWithError("追加オプション: " + e.getMessage());
            deleteRecursively(sessionDir);
            return;
        }

        DownloadProgressCallback callback = (progress, etaInSeconds, line) -> runOnUiThread(() -> {
            progressBar.setProgress(Math.max(0, Math.min(1000, Math.round(progress * 10f))));
            String eta = etaInSeconds > 0 ? " / 残り約" + etaInSeconds + "秒" : "";
            statusText.setText(String.format(Locale.JAPAN, "%.1f%%%s\n%s", progress, eta, line == null ? "" : line));
        });

        activeDownload = YtDlp.executeAsync(request, callback);
        new Thread(() -> {
            try {
                YtDlpResponse response = activeDownload.get();
                if (!response.isSuccess()) {
                    throw new RuntimeException("yt-dlp終了コード: " + response.getExitCode());
                }
                List<File> completed = collectCompletedFiles(sessionDir);
                if (completed.isEmpty()) {
                    throw new RuntimeException("保存されたファイルを見つけられませんでした。");
                }
                if (sectionWav) {
                    File input = completed.get(0);
                    File wav = new File(sessionDir, safeBaseName(input.getName()) + " [" + sectionStart.replace(':', '-') + "-" + sectionEnd.replace(':', '-') + "].wav");
                    String command = "-y -ss " + quote(sectionStart) + " -to " + quote(sectionEnd) + " -i " + quote(input.getAbsolutePath()) + " -vn -c:a pcm_s16le -ar 48000 -ac 2 " + quote(wav.getAbsolutePath());
                    com.arthenica.ffmpegkit.Session ffSession = FFmpegKit.execute(command);
                    if (!ReturnCode.isSuccess(ffSession.getReturnCode()) || !wav.isFile()) {
                        throw new RuntimeException("WAV切り出しに失敗しました: " + ffSession.getAllLogsAsString());
                    }
                    completed = new ArrayList<>();
                    completed.add(wav);
                }

                int exported = 0;
                for (File file : completed) {
                    exportToDownloads(file);
                    exported++;
                }
                int finalExported = exported;
                deleteRecursively(sessionDir);
                runOnUiThread(() -> {
                    progressBar.setProgress(1000);
                    statusText.setText("完了: " + finalExported + "ファイルを Download/yt-dlp に保存しました。");
                    Toast.makeText(this, "ダウンロード完了", Toast.LENGTH_LONG).show();
                    resetDownloadButton();
                });
            } catch (Exception e) {
                deleteRecursively(sessionDir);
                runOnUiThread(() -> finishWithError("失敗: " + safe(e.getMessage())));
            }
        }, "ytdlp-finish").start();
    }

    private void exportToDownloads(File source) throws Exception {
        ContentResolver resolver = getContentResolver();
        ContentValues values = new ContentValues();
        values.put(MediaStore.MediaColumns.DISPLAY_NAME, source.getName());
        String mime = URLConnection.guessContentTypeFromName(source.getName());
        values.put(MediaStore.MediaColumns.MIME_TYPE, mime != null ? mime : "application/octet-stream");
        values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/yt-dlp");
        values.put(MediaStore.MediaColumns.IS_PENDING, 1);

        Uri uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Downloadフォルダを作成できませんでした。");

        boolean ok = false;
        try (FileInputStream in = new FileInputStream(source);
             OutputStream out = resolver.openOutputStream(uri, "w")) {
            if (out == null) throw new IllegalStateException("出力先を開けませんでした。");
            byte[] buf = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) out.write(buf, 0, n);
            out.flush();
            ok = true;
        } finally {
            if (ok) {
                ContentValues done = new ContentValues();
                done.put(MediaStore.MediaColumns.IS_PENDING, 0);
                resolver.update(uri, done, null, null);
            } else {
                resolver.delete(uri, null, null);
            }
        }
    }

    private List<File> collectCompletedFiles(File dir) {
        List<File> out = new ArrayList<>();
        File[] files = dir.listFiles();
        if (files == null) return out;
        for (File f : files) {
            if (f.isDirectory()) {
                out.addAll(collectCompletedFiles(f));
            } else {
                String n = f.getName().toLowerCase(Locale.ROOT);
                if (!n.endsWith(".part") && !n.endsWith(".ytdl") && !n.endsWith(".tmp")) out.add(f);
            }
        }
        return out;
    }

    private void pasteClipboard() {
        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (cm == null || !cm.hasPrimaryClip()) return;
        ClipData clip = cm.getPrimaryClip();
        if (clip == null || clip.getItemCount() == 0) return;
        CharSequence text = clip.getItemAt(0).coerceToText(this);
        if (text != null) urlInput.setText(text.toString());
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        CharSequence shared = intent.getCharSequenceExtra(Intent.EXTRA_TEXT);
        if (shared != null && urlInput != null) {
            String url = extractFirstUrl(shared.toString());
            urlInput.setText(url != null ? url : shared.toString());
        }
    }

    private String extractFirstUrl(String text) {
        if (text == null) return null;
        for (String token : text.split("\\s+")) {
            String cleaned = token.trim().replaceAll("[)>\\],。]+$", "");
            if (cleaned.startsWith("https://") || cleaned.startsWith("http://")) return cleaned;
        }
        return null;
    }

    private List<String> splitArgs(String input) {
        List<String> args = new ArrayList<>();
        if (input == null || input.trim().isEmpty()) return args;
        StringBuilder current = new StringBuilder();
        boolean single = false, dbl = false, escape = false;
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            if (escape) {
                current.append(c);
                escape = false;
            } else if (c == '\\' && !single) {
                escape = true;
            } else if (c == '\'' && !dbl) {
                single = !single;
            } else if (c == '"' && !single) {
                dbl = !dbl;
            } else if (Character.isWhitespace(c) && !single && !dbl) {
                if (current.length() > 0) {
                    args.add(current.toString());
                    current.setLength(0);
                }
            } else {
                current.append(c);
            }
        }
        if (escape || single || dbl) throw new IllegalArgumentException("引用符またはエスケープが閉じていません。");
        if (current.length() > 0) args.add(current.toString());
        return args;
    }

    private String quote(String value) {
        return "\"" + value.replace("\"", "\\\"") + "\"";
    }

    private String safeBaseName(String name) {
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        return base.replaceAll("[\\/:*?\"<>|]", "_");
    }

    private void finishWithError(String message) {
        statusText.setText(message);
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        resetDownloadButton();
    }

    private void resetDownloadButton() {
        downloading = false;
        activeDownload = null;
        downloadButton.setText("ダウンロード");
        downloadButton.setEnabled(initialized);
    }

    private void deleteRecursively(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File child : children) deleteRecursively(child);
        }
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private TextView label(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setTextSize(14);
        return tv;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private String safe(String s) {
        return s == null || s.isEmpty() ? "不明なエラー" : s;
    }
}
