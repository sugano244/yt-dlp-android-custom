#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail

PREFIX_DIR="${PREFIX:-/data/data/com.termux/files/usr}"
HOME_DIR="${HOME:-/data/data/com.termux/files/home}"
DOWNLOAD_DIR="/storage/emulated/0/Download/yt-dlp"

if [ ! -x "$PREFIX_DIR/bin/pkg" ]; then
  echo "このスクリプトはTermux内で実行してください。"
  exit 1
fi

echo "[1/6] Android共有ストレージへのアクセスを設定します。"
termux-setup-storage || true

echo "[2/6] パッケージを更新します。"
pkg update -y
pkg upgrade -y

echo "[3/6] Python / pip / FFmpeg をインストールします。"
pkg install -y python python-pip ffmpeg

echo "[4/6] 本家yt-dlpをインストール/更新します。"
python -m pip install -U "yt-dlp[default]"

echo "[5/6] 保存先と設定を作成します。"
mkdir -p "$HOME_DIR/.config/yt-dlp" "$HOME_DIR/bin" "$DOWNLOAD_DIR"
cat > "$HOME_DIR/.config/yt-dlp/config" <<CFG
--paths "$DOWNLOAD_DIR"
--no-mtime
--windows-filenames
--continue
--part
--concurrent-fragments 4
--format "bv*+ba/b"
--merge-output-format mp4
CFG

cat > "$HOME_DIR/bin/termux-url-opener" <<'SCRIPT'
#!/data/data/com.termux/files/usr/bin/bash
set -u
URL="${1:-}"
if [ -z "$URL" ]; then
  echo "URLがありません。"
  exit 1
fi
clear
printf 'yt-dlpで保存します:\n%s\n\n' "$URL"
yt-dlp "$URL"
STATUS=$?
printf '\n'
if [ $STATUS -eq 0 ]; then
  echo "完了: /storage/emulated/0/Download/yt-dlp"
else
  echo "失敗しました。上のログを確認してください。"
fi
printf '\nEnterで閉じます。'
read -r _
exit $STATUS
SCRIPT
chmod +x "$HOME_DIR/bin/termux-url-opener"

cat > "$HOME_DIR/bin/ydl" <<'SCRIPT'
#!/data/data/com.termux/files/usr/bin/bash
exec yt-dlp "$@"
SCRIPT
chmod +x "$HOME_DIR/bin/ydl"

cat > "$HOME_DIR/bin/ydlaudio" <<'SCRIPT'
#!/data/data/com.termux/files/usr/bin/bash
exec yt-dlp -x --audio-format mp3 --audio-quality 0 "$@"
SCRIPT
chmod +x "$HOME_DIR/bin/ydlaudio"

echo "[6/6] 完了しました。"
echo
cat <<'MSG'
使い方:
  1) ブラウザ/YouTube等の「共有」から Termux を選ぶ
     → yt-dlpで Download/yt-dlp に保存

  2) Termuxで直接:
     ydl "URL"

  3) MP3音声のみ:
     ydlaudio "URL"

更新:
  python -m pip install -U "yt-dlp[default]"
MSG
